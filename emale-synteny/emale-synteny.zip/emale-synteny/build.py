"""Normalize the public gggenomes example and build a portable offline app."""
from pathlib import Path
import hashlib
import json
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parent
RAW = ROOT / 'data/raw'
ORDER = ['RCC970_016B', 'E4-10_086', 'Cflag_017B', 'BVI_069', 'BVI_008A', 'E4-10_112']
FAMILIES = {'ATPase', 'MCP', 'MV12', 'MV13_2', 'MV19', 'pri-hel'}


def gff(name):
    rows = []
    for line in (RAW / name).read_text().splitlines():
        if not line or line.startswith('#'):
            continue
        seq, source, kind, start, end, score, strand, phase, attrs = line.split('\t')
        a = dict(x.split('=', 1) for x in attrs.split(';') if '=' in x)
        rows.append(dict(seq_id=seq, start=int(start)-1, end=int(end), strand=strand,
                         id=a['ID'], name=unquote(a.get('Name', '')), note=unquote(a.get('Note', ''))))
    return rows


sequences = {}
for line in (RAW / 'emales.fna').read_text().splitlines():
    if line.startswith('>'):
        seq_id = line[1:].split()[0]
        sequences[seq_id] = ''
    else:
        sequences[seq_id] += line.strip()
seqs = [dict(id=s, length=len(sequences[s]), reverse=s in ORDER[2:5]) for s in ORDER]
genes = gff('emales.gff')
for gene in genes:
    gene['family'] = gene['name'] if gene['name'] in FAMILIES else 'NA'
lookup = {g['id']: g for g in genes}


def protein_position(gene, aa, end=False):
    # BLAST amino-acid coordinates are 1-based inclusive; output is a nucleotide boundary.
    offset = (aa if end else aa-1)*3
    return gene['start']+offset if gene['strand'] == '+' else gene['end']-offset


protein_links = []
seen = set()
for line in (RAW / 'emales-prot-ava.o6').read_text().splitlines():
    a, b, identity, length, mismatch, gap, a1, a2, b1, b2, evalue, bitscore = line.split('\t')
    ga, gb = lookup[a], lookup[b]
    if ga['seq_id'] == gb['seq_id']:
        continue
    pair = tuple(sorted((a, b)))
    if pair in seen:
        continue
    seen.add(pair)
    protein_links.append(dict(seq_id=ga['seq_id'], seq_id2=gb['seq_id'],
        start=protein_position(ga, int(a1)), end=protein_position(ga, int(a2), True),
        start2=protein_position(gb, int(b1)), end2=protein_position(gb, int(b2), True),
        identity=float(identity)*100, gene_id=a, gene_id2=b, aligned_aa=int(length)))
links = []
seen = set()
for line in (RAW / 'emales.paf').read_text().splitlines():
    p = line.split('\t')
    a, a1, a2, strand, b, b1, b2 = p[0], int(p[2]), int(p[3]), p[4], p[5], int(p[7]), int(p[8])
    key = tuple(sorted(((a, a1, a2), (b, b1, b2))))
    if a == b or key in seen:
        continue
    seen.add(key)
    links.append(dict(seq_id=a, seq_id2=b, start=a1, end=a2, start2=b1 if strand=='+' else b2,
                      end2=b2 if strand=='+' else b1, identity=100*int(p[9])/int(p[10])))
gc = []
for line in (RAW / 'emales-gc.bed').read_text().splitlines():
    seq, start, end, label, score = line.split('\t')
    gc.append(dict(seq_id=seq, start=int(start), end=int(end), value=float(score)))
data = dict(title='Six endogenous mavirus-like elements', coordinate_system='0-based-half-open',
    provenance=dict(description='Real gggenomes EMALE01 example, not synthetic data.',
        source='https://github.com/thackl/gggenomes/tree/main/inst/extdata/emales',
        recipe='https://thackl.github.io/gggenomes/',
        paper='https://doi.org/10.7554/eLife.72674',
        files={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(RAW.iterdir())}),
    sequences=seqs, genes=genes, repeats=gff('emales-tirs.gff'), insertions=gff('emales-ngaros.gff'),
    gc=gc, protein_links=protein_links, nucleotide_links=links)
encoded = json.dumps(data, separators=(',', ':'))
(ROOT / 'data/example.json').write_text(encoded+'\n')
template = (ROOT / 'template.html').read_text()
html = template.replace('/* APP_CSS */', (ROOT / 'styles.css').read_text())
html = html.replace('/* EXAMPLE_DATA */', encoded.replace('</', '<\\/'))
html = html.replace('/* APP_JS */', (ROOT / 'app.js').read_text())
(ROOT / 'index.html').write_text(html)
print(f'Built index.html: {len(html):,} bytes; {len(genes)} genes, {len(gc)} GC windows, {len(protein_links)} protein links')
