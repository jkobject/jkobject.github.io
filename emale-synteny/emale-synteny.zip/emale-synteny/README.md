# EMALE genome explorer

A standalone, offline JavaScript/SVG visualizer reproducing the six-genome synteny plot in the supplied reference. Python converts the public source data and bundles the app. **No R, gggenomes runtime, JavaScript framework, npm installation, external fonts, CDN, or web service is required.**

Open `index.html` directly in a browser. Everything needed for the example is embedded in that file. A local web server is optional:

```bash
python3 -m http.server 8875 --bind 127.0.0.1 --directory jeremie/emale-synteny
```

When the server runs on `rambo`, run this on your own computer and open <http://localhost:8875>:

```bash
ssh -N -L 8875:127.0.0.1:8875 rambo
```

## What the reference is

The image is the realistic six-viral-genome example on the [gggenomes homepage](https://thackl.github.io/gggenomes/). It compares endogenous mavirus-like elements (EMALE01) in the marine flagellate *Cafeteria burkhardae*, described by [Hackl et al., eLife 2021, 10:e72674](https://doi.org/10.7554/eLife.72674).

These are actual downloaded example data, not simulated or digitized coordinates. The default rows are RCC970_016B, E4-10_086, Cflag_017B, BVI_069, BVI_008A and E4-10_112. They contain 143 genes, 12 terminal repeat annotations, 3 Ngaro insertions and 2,856 GC windows. The genome lengths range from 20,152 to 26,856 bp. Protein alignments are the reference plot's visible ribbons; DNA alignments are offered as a second view.

| Layer | Input | Meaning |
| --- | --- | --- |
| Genome baselines | `emales.fna` | FASTA sequence lengths, in bp |
| Gene arrows | `emales.gff` | CDS coordinates, strand, names and notes |
| Pale ribbons (default) | `emales-prot-ava.o6` | Protein alignments projected from amino-acid coordinates onto CDS nucleotide coordinates |
| DNA ribbons (optional) | `emales.paf` | Whole-genome alignments |
| Teal end blocks | `emales-tirs.gff` | Terminal inverted repeats |
| Broad teal bands | `emales-ngaros.gff` | Integrated Ngaro retrotransposons |
| Gray wiggles | `emales-gc.bed` | GC fractions in nonoverlapping 50 bp windows |

Gene colors follow the supplied image: ATPase (teal), MCP (orange), MV12 (purple), MV13_2 (pink), MV19 (green), pri-hel (gold), and NA (gray-beige). NA means outside these six displayed families; some of these genes still have annotations available in the inspector. The third, fourth and fifth sequences are reversed initially to match the reference. Only alignments between adjacent rows are rendered. The GC track is centered on the dataset's mean fraction and scaled separately above and below the mean; it is a wiggle, not a percentage axis.

The original data and graphical elements are reproduced, with browser-native rendering rather than pixel-identical raster output. Font metrics, GC scaling and automatic suppression of nearby labels may differ from the supplied image. Downloaded source files are preserved verbatim in `data/raw`; the normalized example records provenance URLs and SHA-256 checksums.

## Interactions

- Hover on genes, ribbons, repeats and insertions to inspect values. Click a gene to highlight its matching proteins and see its annotation and coordinates. Genes can also be selected with Tab and Enter.
- Click a gene-family legend entry to highlight that family.
- Use the zoom buttons or wheel over the genome region; pan by dragging when zoomed or with the position slider.
- Toggle labels, ribbons, GC tracks, repeats and insertions. Filter alignments by percent identity and change ribbon opacity.
- Expand genome orientation and order to flip or reorder rows.
- Import a JSON dataset, download the current data, or export the current chart as SVG or 2× PNG. Data export preserves row order and orientation; the chart exports preserve visual filters and zoom.
- The page reflows on mobile. The scientific plot has a horizontally scrollable minimum width to keep the reference's labels readable.

## Your data

Import `data/example.json` as a full template, or use this minimal example:

```json
{
  "title": "My genomes",
  "coordinate_system": "0-based-half-open",
  "sequences": [
    {"id": "genome-A", "length": 12000, "reverse": false},
    {"id": "genome-B", "length": 13500, "reverse": false}
  ],
  "genes": [
    {"id": "A-MCP", "seq_id": "genome-A", "start": 1000, "end": 2800, "strand": "+", "family": "MCP", "name": "MCP", "note": "Major capsid protein"},
    {"id": "B-MCP", "seq_id": "genome-B", "start": 1400, "end": 3200, "strand": "+", "family": "MCP", "name": "MCP"}
  ],
  "protein_links": [
    {"seq_id": "genome-A", "start": 1000, "end": 2800, "seq_id2": "genome-B", "start2": 1400, "end2": 3200, "identity": 96.2, "gene_id": "A-MCP", "gene_id2": "B-MCP"}
  ],
  "gc": [
    {"seq_id": "genome-A", "start": 0, "end": 50, "value": 0.38},
    {"seq_id": "genome-A", "start": 50, "end": 100, "value": 0.42}
  ]
}
```

The `genes` and `sequences` arrays and coordinate declaration are required. `repeats`, `insertions`, `gc`, `protein_links` and `nucleotide_links` are optional arrays. Feature rows require `seq_id`, `start`, `end`; gene rows also require unique `id` and `strand`. Link rows require both sequence IDs, both coordinate pairs, and `identity` in 0–100; protein links also reference `gene_id` and `gene_id2`. GC `value` is a fraction in 0–1. Link endpoints may descend to express reverse alignments. Other features use ascending endpoints, with direction in `strand`. Unknown gene families are displayed as NA.

All stored coordinates refer to the **original** sequence, even when a row is reversed. GFF's 1-based inclusive intervals become `[start - 1, end)`; BED and PAF already use 0-based half-open intervals. The inspector displays 1-based inclusive coordinates to match common genome annotation conventions. Protein-link endpoints retain gene direction, so reversing a genome transforms the ribbon geometry consistently.

Imports are validated before the current dataset is replaced. Invalid imports show an error and leave the plot intact. Limits: 8 MB per file, 24 sequences, 10,000 genes and 20,000 entries per optional track. Large datasets will be slower because the renderer uses SVG.

## Build and verification

```bash
python3 jeremie/emale-synteny/build.py
node --check jeremie/emale-synteny/app.js
```

`build.py` uses only Python's standard library and the already-downloaded source files. To recreate the downloads, use URLs under `https://raw.githubusercontent.com/thackl/gggenomes/main/inst/extdata/emales/` for the seven files listed above. The checked-in checksums identify this snapshot; rebuilding uses the local copies and does not access the network.

`check_browser.py` is an optional development check requiring Playwright and Chromium. Set `CHROMIUM_PATH` if using a browser outside Playwright's default installation. It verifies offline rendering, selection, zoom, layers, alignment modes, filters, row reversal/order, SVG/PNG/JSON downloads, valid/invalid/custom JSON imports and mobile page overflow. This check passed in Chromium without browser errors. Screenshots and example exports are in `artifacts/`.

## Files and attribution

- `index.html`: portable, self-contained application.
- `app.js`, `styles.css`, `template.html`: editable application sources.
- `build.py`: deterministic data normalization and HTML bundling.
- `data/example.json`, `data/raw/`: normalized dataset and original public inputs.
- `check_browser.py`, `artifacts/`: browser verification and previews.

Data and the reference composition are credited to Thomas Hackl and the gggenomes authors; the original package is MIT licensed. The associated paper is CC BY. See the linked source repository and paper for their terms. This application does not run or depend on that package.
