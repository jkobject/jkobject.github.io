"""Exercise the offline visualizer with Playwright (development check only)."""
from pathlib import Path
import json
import os
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
ARTIFACTS = ROOT / 'artifacts'
ARTIFACTS.mkdir(exist_ok=True)
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, executable_path=os.environ.get('CHROMIUM_PATH'), args=['--no-sandbox'])
    page = browser.new_page(viewport={'width': 1440, 'height': 1200}, device_scale_factor=1)
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.goto((ROOT / 'index.html').as_uri())
    assert page.locator('.gene').count() == 143
    original_links = page.locator('.link').count()
    assert original_links > 0
    page.screenshot(path=str(ARTIFACTS / 'desktop.png'), full_page=True)
    page.locator('#plot').screenshot(path=str(ARTIFACTS / 'reference-plot.png'))
    page.locator('.gene').first.click()
    assert 'bp' in page.locator('#detail-text').inner_text()
    page.locator('#clear-selection').click()
    page.locator('#zoom-in').click()
    assert page.locator('#zoom-level').inner_text() == '1.5×'
    assert page.locator('#pan').is_enabled()
    page.locator('#reset').click()
    page.locator('#show-links').uncheck()
    assert page.locator('.link').count() == 0
    page.locator('#show-links').check()
    page.locator('#nucleotide').click()
    assert page.locator('.link').count() > 0
    page.locator('#protein').click()
    page.locator('#opacity').fill('40')
    assert page.locator('#opacity-value').inner_text() == '40%'
    page.locator('#identity').fill('100')
    assert page.locator('.link').count() < original_links
    page.locator('#identity').fill('0')
    page.locator('.sequence-controls summary').click()
    path_before = page.locator('.gene').first.get_attribute('d')
    page.get_by_role('button', name='Reverse RCC970_016B', exact=True).click()
    assert page.locator('.gene').first.get_attribute('d') != path_before
    page.get_by_role('button', name='Move RCC970_016B down', exact=True).click()
    page.locator('#example').click()
    for button, name in [('export-svg', 'emale-synteny.svg'), ('export-png', 'emale-synteny.png'), ('download-data', 'emale-dataset.json')]:
        with page.expect_download() as result:
            page.locator('#'+button).click()
        download = result.value
        assert download.suggested_filename == name
        download.save_as(ARTIFACTS / name)
        assert (ARTIFACTS / name).stat().st_size > 1000
    page.locator('#upload').set_input_files(ROOT / 'data/example.json')
    assert page.locator('#dataset-name').inner_text() == 'example.json'
    page.locator('#upload').set_input_files({'name':'invalid.json','mimeType':'application/json','buffer':b'{"coordinate_system":"wrong"}'})
    assert page.locator('#error').is_visible()
    assert page.locator('.gene').count() == 143
    custom = dict(coordinate_system='0-based-half-open', sequences=[dict(id='small',length=1000)],
                  genes=[dict(id='gene1',seq_id='small',start=100,end=800,strand='+',family='MCP')])
    page.locator('#upload').set_input_files({'name':'small.json','mimeType':'application/json','buffer':json.dumps(custom).encode()})
    assert page.locator('.gene').count() == 1
    assert not page.locator('#error').is_visible()
    page.locator('#example').click()
    page.locator('.sequence-controls summary').click()
    for width in [390,320]:
        page.set_viewport_size({'width':width,'height':900})
        assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
    page.screenshot(path=str(ARTIFACTS / 'mobile.png'),full_page=True)
    assert not errors, errors
    browser.close()
print('PASS: offline rendering, selection, zoom, layers, alignment modes, filters, orientation, ordering, SVG/PNG/JSON export, JSON import, invalid import, custom dataset, mobile layout; no browser errors.')
