(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const NS = 'http://www.w3.org/2000/svg';
  const COLORS = {ATPase:'#1b9e77', MCP:'#d95f02', MV12:'#7570b3', MV13_2:'#e7298a', MV19:'#66a61e', 'pri-hel':'#e6ab02', NA:'#cdcdbb'};
  const FAMILIES = Object.keys(COLORS);
  const EXAMPLE = JSON.parse($('example-data').textContent);
  let data = structuredClone(EXAMPLE);
  let selected = null, family = null, mode = 'protein', zoom = 1, offset = 0;
  let rowOrder = data.sequences.map(s=>s.id);
  const svg = $('plot');
  const bp = v => Math.round(v).toLocaleString('en-US');
  const make = (tag, attrs={}, parent=svg, text=null) => {
    const e = document.createElementNS(NS,tag);
    for(const [k,v] of Object.entries(attrs)) e.setAttribute(k,v);
    if(text !== null) e.textContent = text;
    parent.appendChild(e); return e;
  };
  function tip(e, message) {
    const box=$('tooltip'), wrap=$('plot').parentElement, r=wrap.getBoundingClientRect();
    box.textContent=message; box.hidden=false;
    box.style.left=Math.max(4,Math.min(e.clientX-r.left+wrap.scrollLeft+12,wrap.scrollLeft+wrap.clientWidth-310))+'px';
    box.style.top=Math.max(4,e.clientY-r.top+wrap.scrollTop-65)+'px';
  }
  function hover(node,message) {
    node.addEventListener('pointermove',e=>tip(e,message));
    node.addEventListener('pointerleave',()=>{$('tooltip').hidden=true;});
    make('title',{},node,message);
  }
  const visible = id => $(id).checked;
  const maxLength = () => Math.max(...data.sequences.map(s=>s.length));
  function transformed(id,pos){const s=data.sequences.find(s=>s.id===id);return s.reverse?s.length-pos:pos;}
  function render(){
    $('tooltip').hidden=true;
    svg.replaceChildren();
    const H=Math.max(650,140+rowOrder.length*86), left=220, width=775, top=78, step=86, axis=H-47;
    svg.setAttribute('viewBox',`0 0 1280 ${H}`);
    make('title',{},svg,data.title || 'Genome synteny');
    make('desc',{},svg,`${rowOrder.length} genomes. Gene arrows show length and strand, ribbons show ${mode} alignments, gray tracks show GC-content, teal blocks show repeats. Select a gene to inspect.`);
    make('rect',{x:0,y:0,width:1280,height:H,fill:'white'});
    const clip=make('clipPath',{id:'genome-clip'},make('defs'));
    make('rect',{x:left-2,y:0,width:width+4,height:axis-25},clip);
    const chart=make('g',{'clip-path':'url(#genome-clip)'});
    const span=maxLength()/zoom;
    offset=Math.max(0,Math.min(offset,maxLength()-span));
    const x=(id,pos)=>left+(transformed(id,pos)-offset)/span*width;
    const y=id=>top+rowOrder.indexOf(id)*step;
    const linkSet=data[mode+'_links'] || [];
    const threshold=+$('identity').value, opacity=+$('opacity').value/100;
    const geneMap=new Map(data.genes.map(g=>[g.id,g]));
    const activeIds=new Set(selected?[selected.id]:[]);
    if(selected)for(const l of data.protein_links||[]){
      if(l.gene_id===selected.id)activeIds.add(l.gene_id2);
      if(l.gene_id2===selected.id)activeIds.add(l.gene_id);
    }
    let drawnLinks=0;
    if(visible('show-links'))for(const l of linkSet){
      const a=rowOrder.indexOf(l.seq_id),b=rowOrder.indexOf(l.seq_id2);
      if(Math.abs(a-b)!==1 || l.identity<threshold)continue;
      if(family && mode==='protein' && geneMap.get(l.gene_id)?.family!==family && geneMap.get(l.gene_id2)?.family!==family)continue;
      const highlighted=selected && (l.gene_id===selected.id||l.gene_id2===selected.id);
      const ya=y(l.seq_id)+(a<b?15:-15),yb=y(l.seq_id2)+(b<a?15:-15);
      const path=`M${x(l.seq_id,l.start)},${ya} L${x(l.seq_id,l.end)},${ya} L${x(l.seq_id2,l.end2)},${yb} L${x(l.seq_id2,l.start2)},${yb} Z`;
      const mark=make('path',{d:path,fill:highlighted?'#527d64':'#718b72','fill-opacity':selected?(highlighted?Math.min(0.65,opacity+0.16):0.04):opacity,stroke:'white','stroke-width':0.55,'stroke-opacity':0.38,class:'link'},chart);
      hover(mark,`${mode==='protein'?'Protein homology':'DNA alignment'}\n${l.seq_id} ↔ ${l.seq_id2}\nIdentity: ${l.identity.toFixed(1)}%${l.aligned_aa?' · '+l.aligned_aa+' amino acids':''}`);
      drawnLinks++;
    }
    for(const seq of data.sequences){
      if(!rowOrder.includes(seq.id))continue;
      const yy=y(seq.id);
      if(visible('show-insertions'))for(const f of data.insertions||[]){
        if(f.seq_id!==seq.id)continue;
        const a=Math.min(x(seq.id,f.start),x(seq.id,f.end)),b=Math.max(x(seq.id,f.start),x(seq.id,f.end));
        const band=make('rect',{x:a,y:yy-23,width:b-a,height:46,fill:'#60928b','fill-opacity':0.3},chart);
        hover(band,`Ngaro retrotransposon\n${seq.id} · ${bp(f.start+1)}–${bp(f.end)} bp\n${bp(f.end-f.start)} bp`);
      }
      if(visible('show-gc')){
        const points=(data.gc||[]).filter(g=>g.seq_id===seq.id).map(g=>[x(seq.id,(g.start+g.end)/2),g.value]).sort((a,b)=>a[0]-b[0]);
        if(points.length){
          // Original wiggle convention: center on mean GC and scale lower/upper excursions separately.
          const values=(data.gc||[]).map(g=>g.value),mid=values.reduce((a,b)=>a+b,0)/values.length;
          const low=Math.min(...values),high=Math.max(...values),base=yy+19;
          const trace=points.map(([xx,v])=>`${xx},${base-(v-mid)/(v>=mid?Math.max(0.01,high-mid):Math.max(0.01,mid-low))*9}`).join(' L');
          const mark=make('path',{d:`M${points[0][0]},${base} L${trace} L${points.at(-1)[0]},${base} Z`,fill:'#8b8386'},chart);
          hover(mark,`GC-content · ${seq.id}\nMeasured in 50 bp windows\nMean: ${(points.reduce((a,p)=>a+p[1],0)/points.length*100).toFixed(1)}%`);
        }
      }
      make('line',{x1:x(seq.id,0),x2:x(seq.id,seq.length),y1:yy,y2:yy,stroke:'#172522','stroke-width':1.5},chart);
      if(visible('show-repeats'))for(const r of data.repeats||[]){
        if(r.seq_id!==seq.id)continue;
        const a=Math.min(x(seq.id,r.start),x(seq.id,r.end)),b=Math.max(x(seq.id,r.start),x(seq.id,r.end));
        const mark=make('rect',{x:a,y:yy-14,width:b-a,height:28,fill:'#638b87'},chart);
        hover(mark,`Terminal inverted repeat\n${seq.id} · ${bp(r.start+1)}–${bp(r.end)} bp`);
      }
      const labels=[];
      for(const g of data.genes.filter(g=>g.seq_id===seq.id)){
        const a=Math.min(x(seq.id,g.start),x(seq.id,g.end)),b=Math.max(x(seq.id,g.start),x(seq.id,g.end)),head=Math.min(7,(b-a)*0.5),hh=6.5;
        const forward=(g.strand==='+' && !seq.reverse)||(g.strand==='-' && seq.reverse);
        const path=forward?`M${a},${yy-hh} L${b-head},${yy-hh} L${b},${yy} L${b-head},${yy+hh} L${a},${yy+hh} Z`:`M${b},${yy-hh} L${a+head},${yy-hh} L${a},${yy} L${a+head},${yy+hh} L${b},${yy+hh} Z`;
        const dim=(selected&&!activeIds.has(g.id))||(family&&g.family!==family);
        const mark=make('path',{d:path,fill:COLORS[g.family]||COLORS.NA,stroke:'#171b16','stroke-width':1.8,'fill-opacity':dim?0.2:1,'stroke-opacity':dim?0.22:1,class:'gene',tabindex:0,role:'button','aria-label':`${g.name||'Unannotated gene'} ${g.id}, ${bp(g.start+1)} to ${bp(g.end)} base pairs, ${g.strand} strand`},chart);
        hover(mark,`${g.name||'Unannotated gene'} · ${g.id}\n${g.note||'No functional annotation'}\n${bp(g.start+1)}–${bp(g.end)} bp · ${g.strand} strand\nClick to inspect matching genes`);
        mark.addEventListener('click',()=>{selected=g;render();});
        mark.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();selected=g;render();$('clear-selection').focus();}});
        if(visible('show-labels')&&g.family!=='NA'&&!dim&&b>=left&&a<=left+width){
          const xx=(a+b)/2;
          // Mirror the reference's check_overlap behavior for closely packed duplicate labels.
          if(!labels.some(p=>Math.abs(p-xx)<19)){
            make('text',{x:xx,y:yy-15,transform:`rotate(-48 ${xx} ${yy-15})`,'font-family':'Arial,sans-serif','font-size':16,fill:'#171b16','text-anchor':'start'},chart,g.family);
            labels.push(xx);
          }
        }
      }
      if(visible('show-insertions'))for(const f of data.insertions||[]){
        if(f.seq_id===seq.id){const a=Math.min(x(seq.id,f.start),x(seq.id,f.end));make('text',{x:a+3,y:yy-9,'font-family':'Arial,sans-serif','font-size':16,fill:'#171b16'},chart,'Ngaro-transposon');}
      }
      make('text',{x:183,y:yy+7,'text-anchor':'end','font-family':'Arial,sans-serif','font-size':20,fill:'#171b16'},svg,seq.id);
    }
    // Reference-style bottom scale and right-hand legends.
    make('line',{x1:20,x2:1041,y1:axis,y2:axis,stroke:'#171b16','stroke-width':2});
    const tickStep=span>18000?10000:span>8000?5000:span>3000?2000:span>1500?1000:500;
    for(let v=Math.ceil(offset/tickStep)*tickStep;v<=offset+span;v+=tickStep){
      const xx=left+(v-offset)/span*width;
      make('line',{x1:xx,x2:xx,y1:axis,y2:axis+5,stroke:'#171b16'});
      make('text',{x:xx,y:axis+23,'text-anchor':'middle','font-family':'Arial,sans-serif','font-size':16,fill:'#171b16'},svg,v===0?'0':v/1000+'k');
    }
    make('text',{x:1080,y:110,'font-family':'Arial,sans-serif','font-size':28,fill:'#171b16'},svg,'Genes');
    FAMILIES.forEach((f,i)=>{
      const yy=145+i*39;
      const group=make('g',{role:'button',tabindex:0,'aria-label':`Highlight ${f} genes`,'aria-pressed':family===f?'true':'false',style:'cursor:pointer'});
      make('rect',{x:1077,y:yy-16,width:180,height:33,fill:family===f?'#edf3eb':'white'},group);
      make('path',{d:`M1084,${yy-11} L1103,${yy-11} L1115,${yy} L1103,${yy+11} L1084,${yy+11} Z`,fill:COLORS[f],stroke:'#171b16','stroke-width':1.8},group);
      make('text',{x:1132,y:yy+7,'font-family':'Arial,sans-serif','font-size':22,fill:'#171b16'},group,f);
      make('title',{},group,`Click to highlight ${f}; click again to show all`);
      const select=()=>{family=family===f?null:f;selected=null;render();};
      group.addEventListener('click',select);group.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();select();}});
    });
    make('text',{x:1080,y:470,'font-family':'Arial,sans-serif','font-size':28,fill:'#171b16'},svg,'linetype');
    make('rect',{x:1082,y:488,width:36,height:36,fill:'#8b8386'});
    make('text',{x:1132,y:514,'font-family':'Arial,sans-serif','font-size':22,fill:'#171b16'},svg,'GC-content');
    $('zoom-level').textContent=zoom.toFixed(zoom===1?0:1)+'×';
    $('range-label').textContent=`${(offset/1000).toFixed(1)}–${((offset+span)/1000).toFixed(1)} kb`;
    $('pan').max=Math.max(0,Math.ceil(maxLength()-span));$('pan').value=offset;$('pan').disabled=zoom===1;
    $('pan-value').textContent=bp(offset)+' bp';
    $('dataset-stats').textContent=`${data.sequences.length} genomes · ${data.genes.length} genes · ${drawnLinks} visible alignments`;
    $('clear-selection').hidden=!selected&&!family;
    if(selected){
      $('detail-title').textContent=selected.name||'Unannotated gene';
      const gseq=data.sequences.find(s=>s.id===selected.seq_id);
      $('detail-text').textContent=`${selected.id} · ${bp(selected.start+1)}–${bp(selected.end)} bp · ${bp(selected.end-selected.start)} bp · strand ${selected.strand}${gseq.reverse?' (row reversed)':''} · ${selected.note||'No functional annotation'} · ${activeIds.size-1} matching genes`;
    }else if(family){$('detail-title').textContent=`${family} genes`;$('detail-text').textContent=`${data.genes.filter(g=>g.family===family).length} genes highlighted across ${data.sequences.length} genomes. Click the legend again to clear.`;
    }else{$('detail-title').textContent='Select a gene in the plot';$('detail-text').textContent='Inspect its annotation, strand, genomic coordinates and matching genes.';}
  }
  function renderRows(){
    $('rows').replaceChildren();
    rowOrder.forEach((id,i)=>{
      const row=document.createElement('div');row.className='row-control';
      const title=document.createElement('strong');title.textContent=id;row.appendChild(title);
      const seq=data.sequences.find(s=>s.id===id);
      const flip=document.createElement('button');flip.textContent=seq.reverse?'← Reversed':'→ Forward';flip.setAttribute('aria-label',`Reverse ${id}`);
      flip.onclick=()=>{seq.reverse=!seq.reverse;renderRows();render();};row.appendChild(flip);
      for(const [symbol,direction] of [['↑',-1],['↓',1]]){
        const btn=document.createElement('button');btn.textContent=symbol;btn.disabled=i+direction<0||i+direction>=rowOrder.length;btn.setAttribute('aria-label',`Move ${id} ${direction<0?'up':'down'}`);
        btn.onclick=()=>{[rowOrder[i],rowOrder[i+direction]]=[rowOrder[i+direction],rowOrder[i]];renderRows();render();};row.appendChild(btn);
      }
      $('rows').appendChild(row);
    });
    document.querySelector('.sequence-controls summary span').textContent=`${rowOrder.length} sequences`;
  }
  function changeZoom(factor,anchor=0.5){
    const oldSpan=maxLength()/zoom;zoom=Math.max(1,Math.min(16,zoom*factor));
    offset+=oldSpan*anchor-maxLength()/zoom*anchor;render();
  }
  $('zoom-in').onclick=()=>changeZoom(1.5);$('zoom-out').onclick=()=>changeZoom(1/1.5);
  $('reset').onclick=()=>{zoom=1;offset=0;selected=null;family=null;render();};
  for(const id of ['show-links','show-gc','show-labels','show-insertions','show-repeats'])$(id).onchange=render;
  for(const id of ['opacity','identity'])$(id).oninput=()=>{$(id+'-value').textContent=$(id).value+'%';render();};
  $('pan').oninput=()=>{offset=+$('pan').value;render();};
  for(const value of ['protein','nucleotide'])$(value).onclick=()=>{mode=value;for(const v of ['protein','nucleotide']){$(v).classList.toggle('active',v===value);$(v).setAttribute('aria-pressed',v===value);}render();};
  $('clear-selection').onclick=()=>{selected=null;family=null;render();};
  svg.addEventListener('wheel',e=>{
    const r=svg.getBoundingClientRect(),px=(e.clientX-r.left)/r.width*1280;
    if(px<220||px>995)return;
    e.preventDefault();changeZoom(e.deltaY<0?1.15:1/1.15,(px-220)/775);
  },{passive:false});
  let drag=null;
  svg.addEventListener('pointerdown',e=>{
    if(e.target.closest('.gene,[role=button]')||zoom===1)return;
    drag={x:e.clientX,offset};svg.setPointerCapture(e.pointerId);
  });
  svg.addEventListener('pointermove',e=>{
    if(!drag)return;
    offset=drag.offset-(e.clientX-drag.x)/(svg.getBoundingClientRect().width*775/1280)*maxLength()/zoom;render();
  });
  for(const event of ['pointerup','pointercancel'])svg.addEventListener(event,()=>{drag=null;});
  function download(name,blob){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
  function svgText(){const clone=svg.cloneNode(true);clone.setAttribute('xmlns',NS);clone.setAttribute('width','1280');clone.setAttribute('height',svg.viewBox.baseVal.height);return new XMLSerializer().serializeToString(clone);}
  $('export-svg').onclick=()=>download('emale-synteny.svg',new Blob([svgText()],{type:'image/svg+xml'}));
  $('export-png').onclick=()=>{
    const url=URL.createObjectURL(new Blob([svgText()],{type:'image/svg+xml'})),img=new Image();
    img.onload=()=>{const canvas=document.createElement('canvas');canvas.width=2560;canvas.height=svg.viewBox.baseVal.height*2;canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);canvas.toBlob(blob=>{if(blob)download('emale-synteny.png',blob);},'image/png');URL.revokeObjectURL(url);};
    img.onerror=()=>{URL.revokeObjectURL(url);$('error').hidden=false;$('error').textContent='Could not export PNG. Try SVG export.';};img.src=url;
  };
  $('download-data').onclick=()=>{
    const snapshot=structuredClone(data);snapshot.sequences=rowOrder.map(id=>snapshot.sequences.find(s=>s.id===id));
    download('emale-dataset.json',new Blob([JSON.stringify(snapshot,null,2)],{type:'application/json'}));
  };
  function validate(d){
    const fail=m=>{throw new Error(m);};
    if(!d||d.coordinate_system!=='0-based-half-open')fail('coordinate_system must be "0-based-half-open".');
    if(!Array.isArray(d.sequences)||!d.sequences.length||d.sequences.length>24)fail('Provide 1–24 sequences.');
    const ids=new Set();const lengths=new Map();
    for(const s of d.sequences){if(typeof s.id!=='string'||!s.id||s.id.length>60||ids.has(s.id)||!Number.isInteger(s.length)||s.length<=0)fail('Sequences need unique IDs and positive integer lengths.');ids.add(s.id);lengths.set(s.id,s.length);s.reverse=!!s.reverse;}
    if(!Array.isArray(d.genes)||d.genes.length>10000)fail('genes must be an array with at most 10,000 entries.');
    const geneIds=new Set();
    for(const key of ['genes','repeats','insertions','gc','protein_links','nucleotide_links']){
      if(d[key]===undefined)d[key]=[];
      if(!Array.isArray(d[key])||d[key].length>20000)fail(`${key} must be an array with at most 20,000 entries.`);
      for(const f of d[key]){
        if(!f||!ids.has(f.seq_id))fail(`${key}: unknown sequence ID.`);
        const range=(id,a,b,links=false)=>{if(!Number.isFinite(a)||!Number.isFinite(b)||a<0||b<0||a>lengths.get(id)||b>lengths.get(id)||a===b||(!links&&a>b))fail(`${key}: invalid coordinates.`);};
        const isLink=key.endsWith('_links');range(f.seq_id,f.start,f.end,isLink);
        if(isLink){if(!ids.has(f.seq_id2))fail(`${key}: unknown target sequence.`);range(f.seq_id2,f.start2,f.end2,true);if(!Number.isFinite(f.identity)||f.identity<0||f.identity>100)fail(`${key}: identity must be 0–100.`);}
        if(key==='genes'){if(typeof f.id!=='string'||!f.id||geneIds.has(f.id))fail('Genes need unique IDs.');geneIds.add(f.id);if(!['+','-','.'].includes(f.strand))fail('Gene strand must be +, - or .');if(!FAMILIES.includes(f.family))f.family='NA';}
        if(key==='gc'&&(!Number.isFinite(f.value)||f.value<0||f.value>1))fail('GC values must be fractions from 0 to 1.');
      }
    }
    for(const l of d.protein_links){if(!geneIds.has(l.gene_id)||!geneIds.has(l.gene_id2))fail('Protein links must reference valid gene IDs.');}
    return d;
  }
  function load(d,label){data=d;rowOrder=d.sequences.map(s=>s.id);selected=null;family=null;zoom=1;offset=0;$('dataset-name').textContent=label;$('error').hidden=true;renderRows();render();}
  $('upload').onchange=async()=>{
    const file=$('upload').files[0];if(!file)return;
    try{if(file.size>8*1024*1024)throw new Error('Choose a JSON file smaller than 8 MB.');const parsed=validate(JSON.parse(await file.text()));load(parsed,file.name);}
    catch(e){$('error').hidden=false;$('error').textContent='Import failed: '+e.message;}
    finally{$('upload').value='';}
  };
  $('example').onclick=()=>load(structuredClone(EXAMPLE),'gggenomes · real example data');
  validate(data);renderRows();render();
})();
